"""
@Author : Tejas Shinde
@date : 27th April 2024
"""

import sys

def partition(L:[int],p:int ,r:int)-> int:
    """
    Incomplete !!!!
    @Output : index q satisfying postcondition
    @precondition: 
        1) 0 <= p < r < len(L)  
    @postcondition:
        1) Element L[r] moved to position q between p and r

    """
    i =  p-1
    pivot = L[r]
    for j in range(p,r): # itereate from p to r-1
        if L[j] <= pivot:
            i=i+1
            L[i],L[j] = L[j],L[i]
    L[i+1],L[r] = L[r],L[i+1]
    return (i+1) #index of pivot element after setting


def main():
    L = [  100,200,300,
        25,60,63,23,40,45,70,30,55,50,
        1000,456,-122
    ]
    p = L.index(25)
    r = L.index(50)

    q =  partition(L,p,r)

    print(f"L[{q}] : {L[q]}")
    print(f'L[{p}:{q}] : {L[p:q]}')
    print(f"L[{q+1}:{r+1}] : {L[q+1 : r+1]}")
    print(f"{L[p:r+1]}")

    sys.exit(0)

main()